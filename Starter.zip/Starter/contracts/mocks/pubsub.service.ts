import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Rx';
import { PubSubServiceContract } from '../src/pubsub-service.contract';

@Injectable()
export class PubSubService extends PubSubServiceContract {
    private subjects: { [index: string]: Subject<any> };
    constructor() {
        super();
        this.subjects = {};
    }
    publish(subject: string, value: any) {
        let rxSubject = this.subjects[subject];
        if (!rxSubject) {
            rxSubject = this.subjects[subject] = new Subject<any>();
        }
        rxSubject.next(value);
    }
    subscribe(subject: string, handler: (value: any) => void, error?: (error: any) => void, complete?: () => void) {
        let rxSubject = this.subjects[subject];
        if (!rxSubject) {
            rxSubject = this.subjects[subject] = new Subject<any>();
        }
        return rxSubject.subscribe(handler, error, complete);
    }
}
