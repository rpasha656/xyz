import { OpaqueToken } from '@angular/core';

export var Title = new OpaqueToken('Title');
