import { Component, Inject } from '@angular/core';
import { Todo } from './todo.model';
import { Title, PubSubServiceContract } from 'microui-contracts';
import './todolist.html';
@Component({
    moduleId: module.id,
    selector: 'as-todolist',
    template: require('./todolist.html')
})
export class TodolistComponent {
    public todo: Todo;
    private list: Todo[];
    private showCompleted: Boolean;

    constructor(private pubsub: PubSubServiceContract, @Inject(Title) public title: string) {
        this.showCompleted = true;
        this.todo = new Todo('Add me to list!', false);
        this.list = [
            new Todo('Its cool'),
            new Todo('Hello', true)
        ];
    }

    addTodo() {
        let todo = Todo.clone(this.todo);
        this.list = this.list.concat(todo);
        this.todo.clear();
        this.pubsub.publish('Todo', {
            action: 'added',
            value: todo
        });
    }

    delTodo(todoIndex: number) {
        this.list = this.list.filter((todo, index) => index !== todoIndex);
        this.pubsub.publish('Todo', {
            action: 'deleted',
            value: todoIndex
        });
    }

    logTodo(todoIndex: number) {
        this.pubsub.publish('Todo', {
            action: 'toggle status',
            value: {
                name: this.list[todoIndex].name,
                previous: this.list[todoIndex].done,
                current: !this.list[todoIndex].done
            }
        });
    }
}
