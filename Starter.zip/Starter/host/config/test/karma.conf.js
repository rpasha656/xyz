var argv = require('yargs')
  .alias('w', 'watch')
  .argv;
module.exports = function (config) {
  var gulpConfig = require('../gulp/config')();

  var preprocessors = {}, reporters = (argv.debug)?[]:['progress', 'coverage'];
  var browsers = [];

  if (!argv.debug) {
    preprocessors[gulpConfig.tmpApp + '**/!(*.spec)+(.js)'] = ['coverage'];
    browsers.push('PhantomJS')
  } else {
    var brwsr = (typeof (argv.browser) == 'string') ? argv.browser : 'Chrome';
    browsers.push(brwsr);
  }

  config.set({
    basePath: '../../',
    frameworks: ['jasmine'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-phantomjs-launcher'),
      require('karma-coverage')
    ],
    customLaunchers: {
      // chrome setup for travis CI using chromium
      Chrome_travis_ci: {
        base: 'Chrome',
        flags: ['--no-sandbox']
      }
    },
    files: [
      'node_modules/core-js/client/shim.min.js',
      'node_modules/zone.js/dist/zone.js',
      'node_modules/zone.js/dist/long-stack-trace-zone.js',
      'node_modules/zone.js/dist/proxy.js',
      'node_modules/zone.js/dist/sync-test.js',
      'node_modules/zone.js/dist/jasmine-patch.js',
      'node_modules/zone.js/dist/async-test.js',
      'node_modules/zone.js/dist/fake-async-test.js',
      'node_modules/systemjs/dist/system.src.js',
      gulpConfig.tmpTest + 'test-helpers/global/**/*.js',
      'config/test/karma-test-shim.js',
      // Distribution folder.
      { pattern: 'dist/**/*', included: false, watched: true }
    ],
    exclude: [
      // Vendor packages might include spec files. We don't want to use those.
      'dist/vendor/**/*.spec.js'
    ],
    preprocessors: preprocessors,
    reporters: reporters,

    // Generate json used for remap-istanbul
    coverageReporter: {
      dir: gulpConfig.report.path,
      reporters: [
        { type: 'json', subdir: 'report-json' },
        { type: 'lcov', subdir: 'coverage' }
      ]
    },
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: true,
    browsers: browsers,
    singleRun: false
  });
}
